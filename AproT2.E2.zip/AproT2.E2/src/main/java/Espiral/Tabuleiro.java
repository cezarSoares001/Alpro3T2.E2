package Espiral;

public class Tabuleiro {

	public static int entradaT(int n, int b){
		if(n<=0 || b<=0){
			throw new IllegalArgumentException();
		}
		return 0;
	}

	
	
}
